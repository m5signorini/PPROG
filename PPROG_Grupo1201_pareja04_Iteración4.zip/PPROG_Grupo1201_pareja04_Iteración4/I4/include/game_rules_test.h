#ifndef GAME_RULES_TEST_H
#define GAME_RULES_TEST_H

void test_game_rules_create();
void test_game_rules_dark();
void test_game_rules_clopen_links();
void test_game_rules_hide_objects();
void test_game_rules_rotation();
void test_game_rules_teleport();
void test_game_rules_drop_objects();

#endif
